package com.guru.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        fun btn(label: String, f: () -> Unit) = Button(this).apply {
            text = label; setOnClickListener { f() }; col.addView(this)
        }
        col.addView(TextView(this).apply {
            text = "Guru\nBolo: \"Hey Guru, youtube kholo aur search kar proboiz\""
            textSize = 18f
        })
        btn("1. Mic aur notification permission") {
            val p = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
            requestPermissions(p.toTypedArray(), 1)
        }
        btn("2. Draw over other apps allow karo") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("Guru ON") { startForegroundService(Intent(this, GuruService::class.java)) }
        btn("Guru OFF") { stopService(Intent(this, GuruService::class.java)) }
        setContentView(col)
    }
}
