package com.guru.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

class GuruService : Service() {
    private var sr: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private val h = Handler(Looper.getMainLooper())
    private var running = false
    private var awakeUntil = 0L
    private val wake = Regex("(hey|hay|hi|he|hei|हे|हेय|हाय)\\s*(guru|gudu|guruji|गुरु|गुरू|गुरुजी)")

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("guru", "Guru", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "guru")
            .setContentTitle("Guru sun raha hai")
            .setContentText("\"Hey Guru\" bolo")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
        if (!running) {
            running = true
            tts = TextToSpeech(this) { tts?.language = Locale("hi", "IN") }
            listen()
        }
        return START_STICKY
    }

    private fun say(s: String) { tts?.speak(s, TextToSpeech.QUEUE_FLUSH, null, "g") }

    private fun listen() {
        if (!running) return
        sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle?) {
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
                    handle(t); again()
                }
                override fun onError(e: Int) { again() }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(b: Bundle?) {}
                override fun onEvent(t: Int, b: Bundle?) {}
            })
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        sr?.startListening(i)
    }

    private fun again() { h.postDelayed({ listen() }, 600) }

    private fun handle(text: String) {
        val t = text.lowercase().trim()
        if (t.isEmpty()) return
        val now = System.currentTimeMillis()
        val m = wake.find(t)
        val cmd: String
        if (m != null) {
            cmd = t.substring(m.range.last + 1).trim()
            if (cmd.isEmpty()) { awakeUntil = now + 8000; say("Ji bolo"); return }
        } else if (now < awakeUntil) {
            cmd = t
        } else return
        awakeUntil = 0
        say(Commands.run(this, cmd))
    }

    override fun onDestroy() {
        running = false
        h.removeCallbacksAndMessages(null)
        sr?.destroy(); tts?.shutdown()
        super.onDestroy()
    }
}
