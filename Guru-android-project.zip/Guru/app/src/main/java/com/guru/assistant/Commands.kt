package com.guru.assistant

import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.net.Uri

object Commands {
    private val FILL = Regex("\\b(open|kholo|khol|kr|kar|karo|aur|and|pe|par|me|mein|ko|ka|ki|please|bhai)\\b|ओपन|खोलो|खोल|करो|कर|और|पर|में|को|का|की|भाई")
    private val SEARCH = Regex("(search|सर्च|खोज|ढूंढ|ढूँढ|dhundh|dhoond)\\s*(kr|kar|karo|कर|करो)?\\s*(.*)$")
    private val OPEN = Regex("open|kholo|khol|ओपन|खोलो|खोल|चालू|chalu")

    private fun has(s: String, vararg k: String) = k.any { s.contains(it) }

    fun run(c: Context, cmd: String): String {
        fun go(i: Intent) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(i) }
        val m = SEARCH.find(cmd)
        val q = (m?.groupValues?.get(3) ?: "").replace(FILL, " ").replace(Regex("\\s+"), " ").trim()
        try {
            if (has(cmd, "youtube", "यूट्यूब", "यूटयूब")) {
                if (q.isEmpty()) return launch(c, "youtube")
                try {
                    go(Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", q))
                } catch (e: Exception) {
                    go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))))
                }
                return "YouTube pe $q search kar diya"
            }
            if (has(cmd, "maps", "मैप्स", "मैप") && q.isNotEmpty()) {
                go(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(q))))
                return "Maps pe $q dhundh raha hu"
            }
            if (m != null && q.isNotEmpty()) {
                go(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q))
                return "Google pe $q search kar diya"
            }
            if (OPEN.containsMatchIn(cmd)) {
                val name = cmd.replace(OPEN, " ").replace(FILL, " ").trim()
                return launch(c, name)
            }
        } catch (e: Exception) { return "Ye nahi ho paya" }
        return "Samajh nahi aaya"
    }

    private fun launch(c: Context, name: String): String {
        val pm = c.packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name.lowercase()) }
            ?: return "$name app nahi mila"
        val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName) ?: return "$name nahi khula"
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.startActivity(i)
        return "$name khol diya"
    }
}
